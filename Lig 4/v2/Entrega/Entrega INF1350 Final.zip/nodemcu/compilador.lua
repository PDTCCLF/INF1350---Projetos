node.compile("maquina.lua")
node.compile("lig4.lua")
node.compile("matriz.lua")
