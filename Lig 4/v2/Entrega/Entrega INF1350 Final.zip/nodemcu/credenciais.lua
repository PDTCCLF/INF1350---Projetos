cred = {
  ssid = "Sua rede",
  pwd = "Senha",
}

return cred
