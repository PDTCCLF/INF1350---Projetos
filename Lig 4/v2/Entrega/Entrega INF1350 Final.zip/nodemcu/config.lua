-- Trocar meuid para cada um dos jogadores
local config = {
  meuid = "LIG4_A03",
  topic = "INF1350_LIG4",
  broker = "139.82.100.100",
  port = 7981
}
return config
