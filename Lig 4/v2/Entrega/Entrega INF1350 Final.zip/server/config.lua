local config = {
    meuid = "LIG4_SERVER",
    topic = "INF1350_LIG4",
    broker = "139.82.100.100",
    port = 7981
}
return config
