cred = {
  ssid = "Reativos",
  pwd = "reativos",
}

return cred
